﻿using System;

public class Calculator
{
    public static void Main(string[] args)
    {
        Console.Write("Enter an operation (+, -, /, *): ");

        // Write code below this line

        // Write code above this line

        Console.WriteLine($"The result of '{first} {opr} {second}' is: {result}");
    }
}
